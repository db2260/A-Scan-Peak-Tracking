
"""
Created on Thu Jul 23 11:03:21 2020

@author: Nisha
"""


# import os
# os.system('clear')
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.signal import savgol_filter
#import numpy as np
from scipy.signal import find_peaks
# from UliEngineering.SignalProcessing.Utils import zero_crossings
dt =1/250

#Give Ascan location below

data = pd.read_csv(r'C:\Users\KALIDASS\Desktop\XYMA\deepta\ascans\1 (2).csv', sep=',', error_bad_lines=False, index_col=False, dtype='unicode')
data = data.replace(np.inf, np.nan).replace(-np.inf, np.nan).dropna()
a= data[2:]['average(A)']
Trigger = 0
n = len(a)

ydash1 = a.values.ravel()

ydash11 = ydash1.astype(float)

data2 = ydash11[Trigger:n]

peaks, _ = find_peaks(data2, height= 1.0, distance=4000) #height is threshold value
#plt.plot(y2)
#print(peaks[0])s

# peaks1 = peaks+30000 

# Gateing

# Start_P11 = (peaks[0]-500)
# End_P11 = (peaks[0]+500)

# Start_P12 = (peaks[1]-500)
# End_P12 = (peaks[1]+500)

# Start_P21 = (peaks[2]-500)
# End_P21 = (peaks[2]+500)

# Start_P22 = (peaks[3]-500)
# End_P22 = (peaks[3]+500) 

# Start_P31 = (peaks[4]-500)
# End_P31 = (peaks[4]+500)

# Start_P32 = (peaks[5]-500)
# End_P32 = (peaks[5]+500)

# Start_P41 = (peaks[6]-500)
# End_P41 = (peaks[6]+500)

# TOF Determination

# TOF_1 = (peaks[1] - peaks[0])*dt
# print(TOF_1)
# TOF_2 = (peaks[2] - peaks[1])*dt
# print(TOF_2)
# TOF_3 = (peaks[3] - peaks[2])*dt
# print(TOF_3)
# TOF_4 = (peaks[4] - peaks[3])*dt
# print(TOF_4)



plt.plot(data2)

plt.plot(peaks, data2[peaks], "x")

plt.show()
